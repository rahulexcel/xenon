'use strict';

var app = angular.module('xenon-frontend', [
     'ngResource',
    'ui.router'
]);
