(function() {
    'use strict';
    angular.module('xenon-frontend')
        .constant('Configurations', {
            Hostserver: 'https://protected-badlands-3499.herokuapp.com'
        })
        .constant('locationID',{
              locationID:'569500a935e83c1100ac356e'
        });
})();
